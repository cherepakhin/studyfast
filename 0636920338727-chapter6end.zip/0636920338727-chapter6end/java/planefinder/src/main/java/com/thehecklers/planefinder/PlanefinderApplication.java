package com.thehecklers.planefinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlanefinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlanefinderApplication.class, args);
	}

}
