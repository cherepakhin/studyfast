package com.thehecklers.sburjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SburJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SburJpaApplication.class, args);
	}

}
