package com.thehecklers.sburmongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SburMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SburMongoApplication.class, args);
	}

}
