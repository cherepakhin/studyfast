rootProject.name = "sbur-redis"
