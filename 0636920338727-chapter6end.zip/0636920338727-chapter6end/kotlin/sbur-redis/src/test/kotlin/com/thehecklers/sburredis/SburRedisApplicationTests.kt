package com.thehecklers.sburredis

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SburRedisApplicationTests {

	@Test
	fun contextLoads() {
	}

}
