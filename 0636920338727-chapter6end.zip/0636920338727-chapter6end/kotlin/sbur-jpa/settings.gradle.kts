rootProject.name = "sbur-jpa"
