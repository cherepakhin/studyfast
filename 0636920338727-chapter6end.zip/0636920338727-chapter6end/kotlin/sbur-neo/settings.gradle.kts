rootProject.name = "sbur-neo"
