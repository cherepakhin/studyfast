package com.thehecklers.sburneo

import org.springframework.data.repository.CrudRepository

interface AircraftRepository: CrudRepository<Aircraft, Long>
