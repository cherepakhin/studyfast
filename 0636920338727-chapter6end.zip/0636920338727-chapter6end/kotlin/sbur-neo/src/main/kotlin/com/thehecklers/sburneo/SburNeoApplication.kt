package com.thehecklers.sburneo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SburNeoApplication

fun main(args: Array<String>) {
	runApplication<SburNeoApplication>(*args)
}
