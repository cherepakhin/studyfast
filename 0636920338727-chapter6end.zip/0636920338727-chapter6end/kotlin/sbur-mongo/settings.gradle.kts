rootProject.name = "sbur-mongo"
