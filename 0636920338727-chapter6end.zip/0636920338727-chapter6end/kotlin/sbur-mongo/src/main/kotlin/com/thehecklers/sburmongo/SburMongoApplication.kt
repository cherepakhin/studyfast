package com.thehecklers.sburmongo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SburMongoApplication

fun main(args: Array<String>) {
	runApplication<SburMongoApplication>(*args)
}
