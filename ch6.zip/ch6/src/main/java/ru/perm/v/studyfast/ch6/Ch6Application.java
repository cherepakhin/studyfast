package ru.perm.v.studyfast.ch6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch6Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch6Application.class, args);
	}

}
